import React, { useEffect } from "react";

const Weathercard = ({
  temp,
  humidity,
  pressure,
  weathermood,
  name,
  speed,
  country,
  sunset,
}) => {
  const [weatherState, setWeatheState] = React.useState("");

  useEffect(() => {
    if (weathermood) {
      switch (weathermood) {
        case "Clouds":
          setWeatheState("wi-day-cloudy");
          break;
        case "Haze":
          setWeatheState("wi-fog");
          break;
        case "Clear":
          setWeatheState("wi-day-sunny");
          break;
        case "Mist":
          setWeatheState("wi-dust");
          break;

        default:
          setWeatheState("wi-day-sunny");
          break;
      }
    }
  }, [weathermood]);

  // converting the seconds into time
  let sec = sunset;
  let date = new Date(sec * 1000);
  let timeStr = `${date.getHours()}:${date.getMinutes()}`;
  return (
    <>

  <div class="show_box widget">
                    <div class="iconbox weatherIcon">
                        <i className={`wi ${weatherState}`}></i>
                    </div>
                    <div class="mid_box">
                        <div class="temp_box">
                            <div class="wrap">
                                <div class="temp">
                                    <p>{temp}&#x2103;</p>
                                </div>
                                <div class="temp_info">
                                    <div class="state"><p>{weathermood}</p></div>
                                    <div class="area"><p>{name}, {country}</p></div>
                                </div>
                            </div>
                            <div class="date_box">
                                <div class="date"><p>{new Date().toLocaleString()}</p></div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="morebox">
                        <div class="sunset">
                            <div class="icon">
                                <i className={"wi wi-sunset"}></i>
                            </div>
                            <div class="info">
                                <div class="upinfo"> {timeStr} PM</div>
                                <div class="downinfo">Sunset</div>
                            </div>
                        </div>
                        <div class="humidity">
                            <div class="icon">
                                <i className={"wi wi-humidity"}></i>
                            </div>
                            <div class="info">
                                <div class="upinfo">{humidity}</div>
                                <div class="downinfo">Humidity</div>
                            </div>
                        </div>
                        <div class="pressure">
                            <div class="icon">
                                <i className={"wi wi-rain"}></i>
                            </div>
                            <div class="info">
                                <div class="upinfo">{pressure}</div>
                                <div class="downinfo">Pressure</div>
                            </div>
                        </div>
                        <div class="speed">
                            <div class="icon">
                              <i className={"wi wi-strong-wind"}></i>
                            </div>
                            <div class="info">
                                <div class="upinfo">{speed}</div>
                                <div class="downinfo">Speed</div>
                            </div>
                        </div>
                    </div>
                </div>
    </>
  );
};

export default Weathercard;