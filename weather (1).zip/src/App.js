import React from 'react';
import Temp from './temp'

const App = ()  => {
  return (
    <>
      <Temp />
    </>
  );
};

export default App;
